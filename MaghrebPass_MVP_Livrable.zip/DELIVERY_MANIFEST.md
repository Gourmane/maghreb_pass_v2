# Manifeste de livraison - MaghrebPass MVP

Date de preparation: 2026-05-18

## Contenu livre

- `backend/`: API REST Laravel du MVP.
- `docs/`: checklist de demonstration et exemples d'appels API.
- `PRD_MaghrebPass_MVP.md`: cahier produit du projet.
- `ACCEPTANCE_PHASE_11.md`: validation des criteres d'acceptation.
- `PHASE_12_RISK_MITIGATIONS.md`: risques traites et mitigations appliquees.
- `README.md`: demarrage rapide et liens projet.

## Fonctionnalites backend

- Consultation publique: matchs, hotels, restaurants, attractions.
- Authentification par tokens Laravel Sanctum.
- Gestion des favoris pour utilisateurs connectes.
- Administration protegee par role `admin`.
- CRUD admin sur matchs, hotels, restaurants et attractions.
- Donnees de demo avec 8 matchs, 10 hotels, 10 restaurants, 10 attractions, 1 admin et 2 touristes.
- Upload optionnel de photos admin avec limite de 2 MB par image.

## Comptes de demonstration

| Role | Email | Mot de passe |
| --- | --- | --- |
| Admin | `admin@maghrebpass.test` | `password` |
| Touriste FR | `tourist@maghrebpass.test` | `password` |
| Touriste EN | `emily.carter@maghrebpass.test` | `password` |

## Validation effectuee

Commande:

```bash
cd backend
php artisan test
```

Resultat attendu: 23 tests passes, 145 assertions.

## Notes d'installation

Le projet est configure pour SQLite en local via `backend/.env.example`, ce qui evite une dependance MySQL pour la demo.

Commandes principales:

```bash
cd backend
composer install
copy .env.example .env
php artisan key:generate
php artisan migrate:fresh --seed
php artisan storage:link
php artisan serve
```

## Limites connues

- Le frontend React du PRD n'est pas inclus dans ce workspace.
- L'i18n visuelle avec selecteur FR/EN dependra du frontend.
- La compression image n'est pas implementee; la limite backend de 2 MB est appliquee.
