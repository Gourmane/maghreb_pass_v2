# Phase 11 - Criteres d'acceptation MVP

Statut execute le 2026-05-18.

## Criteres valides cote backend

- Visiteur: consultation publique des matchs, hotels, restaurants et attractions sans compte.
- Utilisateur: inscription, connexion et gestion des favoris.
- Administrateur: acces protege par role admin et CRUD sur les contenus principaux.
- FR/EN: les contenus exposent `description_fr`, `description_en` et `preferred_language`.
- Photos: les champs `photos` sont acceptes cote admin et retournes par les pages de detail API.
- Filtres: le filtre `city` fonctionne sur les quatre modules publics.
- Donnees demo: 8 matchs, 10 hotels, 10 restaurants, 10 attractions, 1 admin et 2 touristes.
- API externe: aucune API externe n'est necessaire pour executer le backend MVP.

## Limites restantes

- L'interface React mentionnee dans le PRD n'est pas presente dans ce workspace.
- L'i18n frontend avec selecteur FR/EN ne peut donc pas etre validee ici.
- L'upload fichier physique n'est pas implemente; l'API stocke et retourne actuellement des URLs de photos.

## Commandes de validation

```bash
cd backend
php artisan test
```
