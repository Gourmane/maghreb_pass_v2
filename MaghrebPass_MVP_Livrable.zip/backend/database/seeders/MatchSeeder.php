<?php

namespace Database\Seeders;

use App\Models\FootballMatch;
use Illuminate\Database\Seeder;

class MatchSeeder extends Seeder
{
    public function run(): void
    {
        $matches = [
            ['Morocco', 'Portugal', null, null, '2026-06-12', '20:00', 'Grand Stade de Casablanca', 'Casablanca', 'A', 'group', 'upcoming'],
            ['France', 'Japan', null, null, '2026-06-13', '18:00', 'Stade de Marrakech', 'Marrakech', 'A', 'group', 'upcoming'],
            ['Spain', 'Senegal', null, null, '2026-06-14', '17:00', 'Stade Prince Moulay Abdellah', 'Rabat', 'B', 'group', 'upcoming'],
            ['Brazil', 'Canada', null, null, '2026-06-15', '21:00', 'Grand Stade de Tanger', 'Tanger', 'B', 'group', 'upcoming'],
            ['England', 'Tunisia', null, null, '2026-06-16', '19:00', 'Grand Stade d Agadir', 'Agadir', 'C', 'group', 'upcoming'],
            ['Germany', 'Egypt', null, null, '2026-06-17', '18:00', 'Complexe Sportif de Fes', 'Fes', 'C', 'group', 'upcoming'],
            ['Argentina', 'Ghana', null, null, '2026-06-18', '20:00', 'Grand Stade de Casablanca', 'Casablanca', 'D', 'group', 'upcoming'],
            ['Netherlands', 'Mexico', null, null, '2026-06-19', '21:00', 'Stade de Marrakech', 'Marrakech', 'D', 'group', 'upcoming'],
        ];

        foreach ($matches as [$teamHome, $teamAway, $scoreHome, $scoreAway, $date, $time, $stadium, $city, $group, $phase, $status]) {
            FootballMatch::updateOrCreate(
                [
                    'team_home' => $teamHome,
                    'team_away' => $teamAway,
                    'match_date' => $date,
                ],
                [
                    'score_home' => $scoreHome,
                    'score_away' => $scoreAway,
                    'match_time' => $time,
                    'stadium' => $stadium,
                    'city' => $city,
                    'group_name' => $group,
                    'phase' => $phase,
                    'status' => $status,
                ],
            );
        }
    }
}
