<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class TouristSeeder extends Seeder
{
    public function run(): void
    {
        $tourists = [
            [
                'name' => 'Tourist Demo',
                'email' => 'tourist@maghrebpass.test',
                'preferred_language' => 'fr',
            ],
            [
                'name' => 'Emily Carter',
                'email' => 'emily.carter@maghrebpass.test',
                'preferred_language' => 'en',
            ],
        ];

        foreach ($tourists as $tourist) {
            User::updateOrCreate(
                ['email' => $tourist['email']],
                [
                    'name' => $tourist['name'],
                    'password' => Hash::make('password'),
                    'role' => 'tourist',
                    'preferred_language' => $tourist['preferred_language'],
                    'is_active' => true,
                    'email_verified_at' => now(),
                ],
            );
        }
    }
}
