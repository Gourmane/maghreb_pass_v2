<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    public function run(): void
    {
        User::updateOrCreate(
            ['email' => 'admin@maghrebpass.test'],
            [
                'name' => 'Admin MaghrebPass',
                'password' => Hash::make('password'),
                'role' => 'admin',
                'preferred_language' => 'fr',
                'is_active' => true,
                'email_verified_at' => now(),
            ],
        );
    }
}
