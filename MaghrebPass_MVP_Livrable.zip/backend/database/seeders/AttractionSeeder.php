<?php

namespace Database\Seeders;

use App\Models\Attraction;
use Illuminate\Database\Seeder;

class AttractionSeeder extends Seeder
{
    public function run(): void
    {
        $attractions = [
            ['Mosquee Hassan II', 'Monument majeur de Casablanca construit face a l Atlantique.', 'Major Casablanca landmark built facing the Atlantic Ocean.', 'Casablanca', 'Boulevard Sidi Mohammed Ben Abdallah', 'Mosquee', 130, '09:00-18:00'],
            ['Ancienne Medina de Casablanca', 'Quartier historique avec ruelles, commerces et ambiance locale.', 'Historic district with alleys, shops and local atmosphere.', 'Casablanca', 'Ancienne Medina', 'Medina', 0, 'Toute la journee'],
            ['Jardin Majorelle', 'Jardin botanique colore et musee emblematique de Marrakech.', 'Colorful botanical garden and iconic Marrakech museum.', 'Marrakech', 'Rue Yves Saint Laurent', 'Musee', 150, '08:00-18:30'],
            ['Palais Bahia', 'Palais historique connu pour ses patios et son artisanat decoratif.', 'Historic palace known for patios and decorative craftsmanship.', 'Marrakech', 'Medina', 'Patrimoine historique', 70, '09:00-17:00'],
            ['Kasbah des Oudayas', 'Site historique de Rabat avec ruelles bleues et vue sur l ocean.', 'Historic Rabat site with blue alleys and ocean views.', 'Rabat', 'Oudayas', 'Patrimoine historique', 0, 'Toute la journee'],
            ['Tour Hassan', 'Monument historique et symbole architectural de Rabat.', 'Historic monument and architectural symbol of Rabat.', 'Rabat', 'Quartier Hassan', 'Patrimoine historique', 0, 'Toute la journee'],
            ['Grottes d Hercule', 'Site naturel celebre pres de Tanger avec ouverture sur l ocean.', 'Famous natural site near Tangier with an opening to the ocean.', 'Tanger', 'Cap Spartel', 'Autre', 60, '10:00-18:00'],
            ['Cap Spartel', 'Point panoramique ou se rencontrent Atlantique et Mediterranee.', 'Scenic point where the Atlantic and Mediterranean meet.', 'Tanger', 'Cap Spartel', 'Plage', 0, 'Toute la journee'],
            ['Plage d Agadir', 'Longue plage urbaine ideale pour promenade et detente.', 'Long city beach ideal for walking and relaxing.', 'Agadir', 'Corniche', 'Plage', 0, 'Toute la journee'],
            ['Medina de Fes', 'Medina classee au patrimoine mondial, connue pour ses souks et monuments.', 'World heritage medina known for souks and monuments.', 'Fes', 'Fes el Bali', 'Medina', 0, 'Toute la journee'],
        ];

        foreach ($attractions as [$name, $descriptionFr, $descriptionEn, $city, $address, $category, $entryPrice, $openingHours]) {
            Attraction::updateOrCreate(
                ['name' => $name],
                [
                    'description_fr' => $descriptionFr,
                    'description_en' => $descriptionEn,
                    'city' => $city,
                    'address' => $address,
                    'category' => $category,
                    'entry_price' => $entryPrice,
                    'opening_hours' => $openingHours,
                    'photos' => ['https://images.unsplash.com/photo-1539650116574-75c0c6d73f6e', 'https://images.unsplash.com/photo-1548018560-c7196548e84d'],
                ],
            );
        }
    }
}
