<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class MatchResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'team_home' => $this->team_home,
            'team_away' => $this->team_away,
            'score_home' => $this->score_home,
            'score_away' => $this->score_away,
            'match_date' => $this->match_date?->toDateString(),
            'match_time' => $this->match_time,
            'stadium' => $this->stadium,
            'city' => $this->city,
            'group_name' => $this->group_name,
            'phase' => $this->phase,
            'status' => $this->status,
        ];
    }
}
