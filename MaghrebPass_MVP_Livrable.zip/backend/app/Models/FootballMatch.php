<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FootballMatch extends Model
{
    use HasFactory;

    protected $table = 'matches';

    protected $fillable = [
        'team_home',
        'team_away',
        'score_home',
        'score_away',
        'match_date',
        'match_time',
        'stadium',
        'city',
        'group_name',
        'phase',
        'status',
    ];

    protected function casts(): array
    {
        return [
            'score_home' => 'integer',
            'score_away' => 'integer',
            'match_date' => 'date',
        ];
    }
}
