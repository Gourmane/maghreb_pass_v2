# MaghrebPass MVP

Application MVP pour accompagner les supporters et touristes pendant la Coupe du Monde 2030 au Maroc.

Le workspace contient actuellement le backend Laravel complet:

- API publique: matchs, hotels, restaurants, attractions
- Authentification Sanctum
- Gestion des favoris
- Administration protegee par role
- Donnees de demonstration
- Tests d'acceptation MVP

## Demarrage rapide

```bash
cd backend
composer install
copy .env.example .env
php artisan key:generate
php artisan migrate:fresh --seed
php artisan storage:link
php artisan serve
```

API: `http://localhost:8000/api`

## Comptes de demo

- Admin: `admin@maghrebpass.test` / `password`
- Touriste FR: `tourist@maghrebpass.test` / `password`
- Touriste EN: `emily.carter@maghrebpass.test` / `password`

## Documents projet

- [PRD_MaghrebPass_MVP.md](PRD_MaghrebPass_MVP.md)
- [ACCEPTANCE_PHASE_11.md](ACCEPTANCE_PHASE_11.md)
- [PHASE_12_RISK_MITIGATIONS.md](PHASE_12_RISK_MITIGATIONS.md)
- [Checklist demo](docs/DEMO_CHECKLIST.md)
- [Exemples API](docs/API_EXAMPLES.md)
- [Backend README](backend/README.md)

## Validation

```bash
cd backend
php artisan test
```

Derniere validation: 23 tests passes, 145 assertions.
